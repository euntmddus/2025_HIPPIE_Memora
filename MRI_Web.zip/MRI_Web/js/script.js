let currentViewMode = '2D';

// DB에서 불러올 환자 배열
let patients = [];

// 기본 MRI 이미지
let mri = [
  { src: 'assets/mri-axial.png',   title: 'Axial' },
  { src: 'assets/mri-coronal.png', title: 'Coronal' }
];

let idx = 0;
let currentPatientIndex = 0;

// DOM 요소
const list          = document.getElementById('patientList');
const ptNameEl      = document.getElementById('ptName');
const ptSexAgeEl    = document.getElementById('ptSexAge');
const viewerRoot    = document.getElementById('mainViewer');
const issuedAtEl    = document.getElementById('issuedAt');
const summaryEl     = document.getElementById('summaryBox');
const logList       = document.getElementById('logList');
const featureListEl = document.getElementById('featureList');
const btnView2D     = document.getElementById('btnView2D');
const btnView3D     = document.getElementById('btnView3D');
const btnUpload     = document.getElementById('btnUpload');

// 유틸
function todayISO() {
  const t = new Date();
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;
}

function log(msg) {
  const row = document.createElement('div');
  row.className = 'row';
  const now = new Date().toLocaleString();
  row.innerHTML = `<span class="mono">${now}</span><span>${msg}</span><span class="mono">sys</span>`;
  logList.prepend(row);
}

// 환자 데이터 DB에서 가져오기
async function loadPatients() {
  const res = await fetch('http://127.0.0.1:8000/api/patients');
  const data = await res.json();

  patients = data.map(row => ({
    id: row.patient_id,
    name: row.name,
    sex: row.sex,
    age: row.age,
    vitals: '',
    icv: '',
    apoe4: 0,
    features: null
  }));

  renderPatients();
}

// Vitals / Features 렌더링
function renderVitals(text) {
  const root = document.getElementById('ptVitals');
  if (!root) return;
  const items = (text || '').split('|').map(s => s.trim()).filter(Boolean);
  root.innerHTML = '';
  items.forEach(item => {
    const [key, ...rest] = item.split(/\s+/);
    const value = rest.join(' ');
    const li = document.createElement('li');
    li.innerHTML = `<span class="vkey">${key}</span><span class="vval">${value}</span>`;
    root.appendChild(li);
  });
}

function renderFeatures(features) {
  if (!featureListEl) return;
  featureListEl.innerHTML = '';
  if (!features) return;

  const rows = [
    ['ICV', features.icv ? `${features.icv.toLocaleString()} mm³` : '—'],
    ['좌 해마 부피', features.left_hipp_vol_mm3 ? `${features.left_hipp_vol_mm3} mm³` : '—'],
    ['우 해마 부피', features.right_hipp_vol_mm3 ? `${features.right_hipp_vol_mm3} mm³` : '—'],
    ['총 해마 부피', features.total_hipp_vol_mm3 ? `${features.total_hipp_vol_mm3} mm³` : '—'],
    ['ICV 보정 해마 지수 (좌/우/총)',
      (features.left_hipp_vol_icv_norm != null &&
       features.right_hipp_vol_icv_norm != null &&
       features.total_hipp_vol_icv_norm != null)
        ? `${features.left_hipp_vol_icv_norm} / ${features.right_hipp_vol_icv_norm} / ${features.total_hipp_vol_icv_norm}`
        : '—'
    ],
    ['APOE4 유전자형', features.apoe4 ?? '정보 없음']
  ];

  rows.forEach(([k, v]) => {
    const li = document.createElement('li');
    li.innerHTML = `<span class="vkey">${k}</span><span class="vval">${v}</span>`;
    featureListEl.appendChild(li);
  });
}

// 환자 리스트 렌더링
function renderPatients() {
  list.innerHTML = '';
  patients.forEach((p, i) => {
    const li = document.createElement('li');
    li.innerHTML = `<span>•</span><span>${p.name}</span><span class="mono">${p.sex}/${p.age}</span>`;
    li.onclick = () => selectPatient(i, li);
    list.appendChild(li);
    if (i === 0) selectPatient(0, li);
  });
}

function selectPatient(i, li) {
  document.querySelectorAll('.patient-list li').forEach(n => n.classList.remove('active'));
  li.classList.add('active');
  currentPatientIndex = i;
  const p = patients[i];
  ptNameEl.textContent = p.name;
  ptSexAgeEl.textContent = `${p.sex} / ${p.age}세`;
  renderVitals(p.vitals);
  renderFeatures(p.features);
  renderViewer();
}

// 뷰어 렌더링
function renderViewer() {
  viewerRoot.innerHTML = '';
  const p = patients[currentPatientIndex];
  if (!p) {
    viewerRoot.textContent = 'No Patient';
    return;
  }
  if (currentViewMode === '2D') {
    render2DView(p);
  } else {
    render3DView(p);
  }
}

function render2DView(p) {
  const img = document.createElement('img');
  img.src = mri[idx].src;
  img.alt = '2D MRI';
  img.style.maxWidth = '100%';
  img.style.maxHeight = '100%';
  viewerRoot.appendChild(img);
}

function render3DView(p) {
  const div = document.createElement('div');
  div.style.display = 'flex';
  div.style.alignItems = 'center';
  div.style.justifyContent = 'center';
  div.style.height = '100%';
  div.textContent = '3D 해마 세그 뷰어 (추후 연동)';
  viewerRoot.appendChild(div);
}

// 버튼 이벤트
btnView2D.onclick = () => {
  currentViewMode = '2D';
  renderViewer();
};

btnView3D.onclick = () => {
  currentViewMode = '3D';
  renderViewer();
};

btnUpload.onclick = () => {
  const input = document.getElementById('fileInput');
  if (input) input.click();
};

document.getElementById('fileInput').onchange = async e => {
  const f = e.target.files[0];
  if (!f) return;

  const url = URL.createObjectURL(f);
  mri.push({ src: url, title: f.name });
  idx = mri.length - 1;
  renderViewer();
  log(`MRI 업로드: ${f.name}`);

  const p = patients[currentPatientIndex];

  try {
    log('서버 분석 시작…');

    const fd = new FormData();
    fd.append('file', f);
    fd.append('patient_id', p.id);
    fd.append('age', String(p.age));
    fd.append('apoe4', String(p.apoe4));
    fd.append('sex', p.sex);
    fd.append('icv', String(p.icv || ""));

    const res = await fetch('http://127.0.0.1:8000/api/process_mri', {
      method: 'POST',
      body: fd
    });

    if (!res.ok) {
      log('서버 오류: ' + res.status);
      return;
    }

    const result = await res.json();
    applyServerResult(result);
    log('분석 완료: ' + (result.label || 'N/A'));
  } catch (err) {
    console.error(err);
    log('분석 실패(네트워크 또는 서버 오류)');
  }
};

// 서버 결과 반영
function applyServerResult(result) {
  const { probs, label, summary, features } = result;

  if (summaryEl && summary) {
    summaryEl.value = summary;
  } else if (summaryEl && probs && label) {
    const CN = Math.round(probs.CN || 0);
    const AD = Math.round(probs.AD || 0);
    const header = `모델 예측: ${label}`;
    const dist   = `확률 분포: CN ${CN}% · AD ${AD}%`;
    summaryEl.value = `${header}\n\n${dist}`;
  }

  if (features) {
    patients[currentPatientIndex].features = features;
    renderFeatures(features);
  }
}

// 초기 화면 세팅
async function init() {
  issuedAtEl.textContent = todayISO();
  await loadPatients();   // DB에서 환자 불러오고 renderPatients() 실행
  renderViewer();         // 첫 환자 기준 뷰어 렌더
}

// 스크립트가 body 끝에 있다면 바로 호출해도 됨
init();
